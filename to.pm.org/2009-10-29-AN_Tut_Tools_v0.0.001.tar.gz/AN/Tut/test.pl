#!/usr/bin/perl -Tw

use strict;
use warnings;
use POSIX;

# Be nice and set a version number.
our $VERSION="0.0.001";

# Call in the test module
use Test::More tests => 28;
# use Test::More 'no_plan';

# Load my module via 'use_ok' test.
BEGIN
{
	print "Will now test AN::Tut::Tools on $^O.\n";
	use_ok('AN::Tut::Tools', 0.0.001);
}

# Get a handle on the main module and test it.
my $an=AN::Tut::Tools->new();
like($an, qr/^AN::Tut::Tools=HASH\(0x\w+\)$/, "AN::Tut::Tools object appears valid.");

# Build an array of methods that 'AN::Tut::Tools' should provide.
my @methods=("Math", "Say");
can_ok("AN::Tut::Tools", @methods);

### test AN::Tut::Tools::Math
print "Testing AN::Tut::Tools::Math\n";
require_ok("AN/Tut/t/Math.t");

### test AN::Tut::Tools::Math
print "Testing AN::Tut::Tools::Say\n";
require_ok("AN/Tut/t/Say.t");

exit;
