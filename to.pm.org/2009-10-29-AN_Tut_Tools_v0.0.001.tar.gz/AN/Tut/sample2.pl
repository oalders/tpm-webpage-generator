#!/usr/bin/perl

# This just sets perl to be strict about how it runs.
use strict;
use warnings;

# Load my module.
use AN::Tut::Sample2;

# Call my constructor method and show the user what is happening.
print "Starting 'sample2.pl'\n";
my $an=AN::Tut::Sample2->new();

# Call the method 'add' using my 'an' object.
my $added_1=$an->add(2, 2);
print "2 + 2 = [$added_1]\n";

# Call the method 'add' using my 'an' object.
my $subtract_1=$an->subtract(9, 4);
print "9 - 4 = [$subtract_1]\n";

# Now show the counts.
my ($module_count, $add_count, $subtract_count)=$an->get_counts();
print "Method call counts; All: [$module_count], add: [$add_count], subtract: [$subtract_count]\n";

# Change this to '1' to see how calling this method directly will trigger an
# error.
if (0)
{
	my $added_2=AN::Tut::Sample2->add(2, 2);
	print "2 + 2 = [$added_2]\n";
}

exit 0;
