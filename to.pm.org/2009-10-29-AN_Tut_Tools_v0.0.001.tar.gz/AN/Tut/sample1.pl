#!/usr/bin/perl

# This just sets perl to be strict about how it runs.
use strict;
use warnings;

# Load my module.
use AN::Tut::Sample1;

# Call my constructor method and show the user what is happening.
print "Here is what happens when I call the 'new' constructor method.\n";
my $an=AN::Tut::Sample1->new();
print "Now, this is what my 'an' object looks like: [$an]\n";

# Call the method 'add' using my 'an' object.
my $added_1=$an->add(2, 2);
print "2 + 2 = [$added_1]\n";

# Call the method 'add' directly via the module.
my $added_2=AN::Tut::Sample1->add(2, 2);
print "2 + 2 = [$added_2]\n";

exit 0;
