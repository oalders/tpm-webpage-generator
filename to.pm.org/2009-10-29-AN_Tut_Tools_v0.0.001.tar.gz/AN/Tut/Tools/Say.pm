package AN::Tut::Tools::Say;

# This sets the version of this file. It will be useful later.
BEGIN
{
	our $VERSION="0.1.001";
}

# This just sets perl to be strict about how it runs and to die in a way
# more compatible with the caller.
use strict;
use warnings;
use Carp;


# The constructor method.
sub new
{
	my $class=shift;
	
	my $self={
		HANDLE_TUT_TOOLS	=>	""
	};
	
	bless ($self, $class);
	
	return ($self);
}

# Get a handle on the AN::Tut::Tools object. I know that technically that is a
# sibling module, but it makes more sense in this case to think of it as a
# parent.
sub _parent
{
	my $self=shift;
	my $parent=shift;
	
	$self->{HANDLE_TUT_TOOLS}=$parent if $parent;
	
	return ($self->{HANDLE_TUT_TOOLS});
}

# This method takes the values given to one of the Math methods, the result and
# the method called plus a language code to create a string to show the user.
sub math
{
	my $self=shift;
	my $param=shift;
	
	# I support two ways to pick up variables, so first I create the
	# empty or default variables here.
	my $task;
	my $num1;
	my $num2;
	my $result;
	my $lang="en";
	
	# Pick out the passed in paramters or switch to reading by array.
	if (ref($param) eq "HASH")
	{
		# Read in variables from the 'param' hash reference.
		$task=$param->{task};
		$num1=$param->{num1};
		$num2=$param->{num2};
		$result=$param->{result};
		$lang=$param->{lang} if exists $param->{lang};
	}
	else
	{
		# 'param' is not a hash reference, so switch to array-mode.
		$task=$param;
		$num1=shift;
		$num2=shift;
		$result=shift;
		$lang=shift if defined $_[0];
	}
	
	# Create the 'say' variable.
	my $say="";
	
	# Now choose the task 
	if ($task eq "add")
	{
		# Adding, now choose the language.
		if ($lang eq "en")
		{
			# English
			$say="I added: [$num1] and: [$num2] and got: [$result].";
		}
		elsif ($lang eq "fr")
		{
			# French
			$say="J'ai additionné: [$num1] et: [$num2] et la somme est: [$result].";
		}
	}
	elsif ($task eq "sub")
	{
		# Subtracting, now choose the language.
		if ($lang eq "en")
		{
			# English
			$say="I subtracted: [$num1] from [$num2] and got: [$result].";
		}
		elsif ($lang eq "fr")
		{
			# French (thanks to Sonja Elen Kisa for correcting my French!)
			$say="J'ai soustrait: [$num1] de: [$num2] et la différence est: [$result].";
		}
	}
	else
	{
		croak "Invalid task: [$task] passed to '\$an->Say->math'. Valid task arguments are 'add' and 'sub'.\n";
	}
	
	return ($say);
}

1;
