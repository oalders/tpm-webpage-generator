#!/usr/bin/perl

# This just sets perl to be strict about how it runs.
use strict;
use warnings;

# Load my module.
use AN::Tut::Tools 0.0.001;

# Call my constructor method.
my $an=AN::Tut::Tools->new();

# Call the 'add' method via the 'Math' method.
my $num1=10;
my $num2=12;
my $result=$an->Math->add($num1, $num2);

### Here are the different ways this method can be called.
# Using the default language 'en', English.
print $an->Say->math("add", $num1, $num2, $result), "\n";
# Specifying the language 'fr', French
print $an->Say->math("add", $num1, $num2, $result, "fr"), "\n";
# Array-type; allows for better self-documenting code and flexible argument
# order.
print $an->Say->math({
	task	=>	"add",
	num1	=>	$num1,
	num2	=>	$num2,
	result	=>	$result,
	lang	=>	"fr"
}), "\n";

# This time I do the print and math at the same time. Ya, it's ugly. :)
$num1=40;
$num2=12;
print $an->Say->math({
	task	=>	"sub",
	num1	=>	$num1,
	num2	=>	$num2,
	result	=>	$an->Math->subtract($num1, $num2),
	lang	=>	"fr"
}), "\n";

# Finally, let's call 'add_and_say' to show how one module's method can call a
# sibling module's method.
print $an->Math->add_and_say(15, 20), "\n";
# Again, but specifying a language.
print $an->Math->add_and_say(2, 18, "fr"), "\n";

exit 0;
