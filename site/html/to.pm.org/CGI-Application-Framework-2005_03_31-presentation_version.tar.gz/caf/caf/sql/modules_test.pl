#!/usr/bin/perl

use warnings;
use strict;

my @required = qw (
                    DB_File
                    Digest::MD5
                    Data::Dumper
                    Time::HiRes
                    Date::Manip
                    Time::Format
                    DBI
                    Class::DBI
                    Class::DBI::AbstractSearch
                    Apache::Session
                    Apache::SessionX
                    CGI
                    CGI::Carp
                    CGI::Enurl
                    HTML::Template
                    CGI::Application
                    CGI::Application::Plugin::ValidateRM
                    Log::Log4perl
                    Regexp::Common
                    Text::CSV_XS
                    IPC::Shareable
                    Module::Load
                    Config::General
                    Config::General::Match
                    CGI::Application::Plugin::Config::General
                    );

my @optional = qw (
                   Apache::DBI
                   FreezeThaw
                   Log::Dispatch
                   Devel::ptkdb
                   DBI::Shell
                   );


my %db_alternates = (
                   mysql  => [qw(
                                 DBD::mysql
                                 Class::DBI::mysql
                             )],
                   Pg     => [qw(
                                 DBD::Pg
                                 Class::DBI::Pg
                             )],
                   SQLite => [qw(
                                 DBD::SQLite
                                 Class::DBI::SQLite
                            )],
                 );

my $req_error = 0;
foreach ( @required ) {
    eval "require $_";
    if ( $@ ) {
        warn "Required module $_ missing with error: $@";
        $req_error = 1;
    }
}
print "All required modules are installed.\n" unless $req_error;

print "\n";

my $opt_error = 0;
foreach ( @optional ) {
    eval "require $_";
    if ( $@ ) {
        warn "Optional module $_ missing with error: $@" if $@;
        $opt_error = 1;
    }
}
print "All optional modules are installed.\n" unless $opt_error;

my $db_okay = 0;
foreach my $db ( keys %db_alternates ) {
    my $missing_db_modules = 0;
    foreach my $module ( @{ $db_alternates{$db} }) {
        eval "require $module";
        if ( $@ ) {
            $missing_db_modules = 1;
        }
    }
    if (!$missing_db_modules) {
        $db_okay = 1;
        print "$db is installed (@{ $db_alternates{$db} })\n";
        next;
    }
}
if ($db_okay) {
    print "At least one database driver and Class::DBI subclass are installed\n";
}
else {
    warn "No database driver is properly installed.\n"
}

exit 0;


