
package CGI::Application::Framework::Template::Petal;

=head1 NAME

CGI::Application::Framework::Template::Petal - Petal plugin to Framework

=head1 DESCRIPTION

This module is a subclass of C<CGI::Application::Framework::Template>.
It provides the implementation details specific to rendering templates via
the C<Petal> template module.

All template modules are designed to be used the same way.  For general usage
instructions, see the documentation of C<CGI::Application::Framework::Template>.

=head1 COMPONENT DISPATCH

B<Note that component dispatch under Petal is unstable at the moment.  There appears>
B<to be a bug where text leading up to the first tag goes missing in an included component.>
B<The workaround is to enclose the entire file in tags: >

    <span>
    var: <span petal:replace="var"></span>
    </span>

The C<Petal> syntax for component dispatch is:

    <span tal:replace="structure FRAMEWORK/dispatch 'some_run_mode'">
        this text gets replaced by the output of some_run_mode
    </span>

This can be overridden by the following configuration variables:

    dispatch_tag_name       # default 'FRAMEWORK'

For instance by setting the following values in your configuration file:

    dispatch_tag_name       'MYAPP'

Then the component dispatch tag will look like:

    <span tal:replace="structure MYAPP/dispatch 'some_run_mode'">
        this text gets replaced by the output of some_run_mode
    </span>

Note that when creating documents to be included as components, they
must be complete XML documents.



=cut

use strict;
use Petal;
use Carp;

use CGI::Application::Framework::TemplateDispatch;

use base 'CGI::Application::Framework::Template';

sub framework_config_params {
    qw/
       dispatch_tag_name
       template_extension
    /;
}

sub framework_config_defaults {
    (
        dispatch_tag_name  => 'FRAMEWORK',
    );
}

# create the Petal object,
# using:
#   $self->get_driver_config         # config info
#   $self->get_include_paths  # the paths to search for the template file
#   $self->filename           # the template file
sub initialize_driver {
    my $self = shift;

    # TODO: check out how Petal caching work

    my %config = %{ $self->get_driver_config };
    $config{'base_dir'} = $self->get_include_paths;
    $config{'file'}     = $self->filename;

    my $driver = Petal->new(%config);

    $self->{'driver'} = $driver;
}

# Fill the Petal object with $self->param.
#
# Set params for each of $self->{'webapp'}->query,
# mimicking HTML::Template's query parameter
#
# Set up a TemplateDispatch object so that
# the FRAMEWORK.dispatch callback will work
#
sub render_template {
    my $self = shift;

    my $framework_config          = $self->get_framework_config;
    my %framework_config_defaults = $self->framework_config_defaults;

    $framework_config->{$_} ||= $framework_config_defaults{$_}
        foreach keys %framework_config_defaults;

    my $template = $self->{'driver'};

    my $output = '';

    # emulate HTML::Template's 'associate' behaviour
    my $params = $self->get_param_hash;
    if ($self->{'webapp'}) {
        foreach ($self->{'webapp'}->query->param) {
            $params->{$_} ||= $self->{'webapp'}->query->param($_);
        }
    }

    my $dispatcher = CGI::Application::Framework::TemplateDispatch->new(
        'webapp' => $self->{'webapp'},
    );

    $params->{$framework_config->{'dispatch_tag_name'}} = $dispatcher;

    $self->{'webapp'}->parent_template_values($self->get_param_hash);

    my $output = $template->process($params) || croak $template->error;
    return \$output;
}

=head1 AUTHOR

Michael Graham, C<< <mag-perl@occamstoothbrush.com> >>

=head1 COPYRIGHT & LICENSE

Copyright 2004 Michael Graham, All Rights Reserved.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

=cut

1;


