package CGI::Application::Framework::Session;

use base 'Apache::SessionX';
use Carp;
use strict;

1;
