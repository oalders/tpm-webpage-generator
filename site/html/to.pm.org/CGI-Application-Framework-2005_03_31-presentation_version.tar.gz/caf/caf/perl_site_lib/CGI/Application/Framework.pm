package CGI::Application::Framework;

use strict;
use warnings;

use lib ('../..');

use base qw / CGI::Application Exporter /;
use vars qw / @EXPORT_OK $AUTOLOAD /;
@EXPORT_OK = qw (
                 load_tmpl
                 session
                 redirect
                 make_link
                 compose_object
                 remove_composed_object
                 list_all_composed_objects
                 param_read_and_set
                 param_read_and_unset
                 AUTOLOAD
                 make_self_url
                 get_session_id
                 compose_template
                 );

use Carp;
use Data::Dumper;

use CGI::Application::Framework::Constants  qw (
                                                 SESSION_FIRST_TIME
                                                 SESSION_IN_COOKIE
                                                 SESSION_IN_HIDDEN_FORM_FIELD
                                                 SESSION_IN_URL
                                                 SESSION_MISSING
                                                 );

use Log::Log4perl;

use CGI::Application::Framework::Session;
use CGI::Application::Plugin::ValidateRM qw / check_rm /;
use CGI::Application::Plugin::Config::General;
use CGI::Enurl ();
use Digest::MD5;
use Time::HiRes;
use File::Basename qw ( fileparse );
use File::Spec;
use Cwd 'abs_path';
use Module::Load;

sub login {

    my $self = shift;

    my $config = $self->conf($self->config_name)->getall;

    $self->log->debug("At top of 'login' subroutine / run mode ");
    # ------------------------------------------------------------------
    # Note that the '_errs' param will be populated if there was
    # an error with the processing of a login form submission; this is a
    # CGI::Application::Plugin::ValidateRM ->check_rm method thing,
    # called from within the 'cgiapp_prerun' subroutine.  There are
    # tmpl_var fields within the .tmpl loaded below that correspond to
    # the entries named in $err.  After reading it, unset it so that
    # it isn't polluted with information the next time this sub is
    # accessed.
    # ------------------------------------------------------------------
    my $errs = shift || $self->param_read_and_unset('_errs');
    $self->log->debug("\$errs is: " . Data::Dumper->Dump([$errs],[qw(*errs)]));

    # ------------------------------------------------------------------

    $self->compose_template(
                              name => 'template',
                              file => 'login.html',
                              type => $self->system_template_type,
                              );

    # ==================================================================
    # Populate the TMPL_VARs in the "login.html" form, as given above.
    # (Note that most of these are actually in the relogin_form.html
    # template file.  Look for these in a tmpls/.common(-*) directory.
    # ==================================================================
    my %tmplvars = ();

    $tmplvars{'FORM_NAME'}   = 'login';
    $tmplvars{'FORM_METHOD'} = 'POST';
    $tmplvars{'FORM_ACTION'} = $self->make_self_url();

    # ---------------------------------------------------
    # Take whatever form params from the $self that are
    # needed per the specific subclass and put these into
    # the template TMPL_VARs via %tmplvars
    # ---------------------------------------------------
    foreach my $hash ( $self->_login_tmpl_params() ) {
        while ( my ($key, $value) = each %$hash ) {
            $tmplvars{$key} = $value;
        }
    }
    # ---------------------------------------------------

    $self->template->param(\%tmplvars);
    $self->template->param($errs) if $errs;
    # ======== end population of tmpl_vars =============================

    return $self->template->output
        (
         webapp => $self,
         run_mode_tags => {
             COMEFROMRUNMODE
                 => [ COMEFROM => $self->get_current_runmode ],
                 CURRENTRUNMODE
                 => [ CURRENT  => $self->get_current_runmode ],
                 SUBMITTORUNMODE
                 => [ SUBMITTO => $config->{'post_login_rm'} ],
             }
         );
}

sub invalid_session {

    my $self = shift;
    # ------------------------------------------------------------------
    # Note that the '_errs' param will be populated if there was
    # an error with the processing of a login form submission; this is a
    # CGI::Application::Plugin::ValidateRM ->check_rm method thing,
    # called from within the 'cgiapp_prerun' subroutine.  There are
    # tmpl_var fields within the .tmpl loaded below that correspond to
    # the entries named in $err.  After reading it, unset it so that
    # it isn't polluted with information the next time this sub is
    # accessed.
    # ------------------------------------------------------------------
    my $errs = shift || $self->param_read_and_unset('_errs');
    # ------------------------------------------------------------------

    $self->compose_template(
        type => $self->system_template_type,
    );

    my $self_url = $self->query->url;
    $self_url   .= $ENV{'PATH_INFO'} if $ENV{'PATH_INFO'};

    $self->template->param( SELF_URL => $self_url );

    $self->template->param($errs) if $errs;

    return $self->template->output();
}

sub invalid_checksum {

    my $self = shift;
    # ------------------------------------------------------------------
    # Note that the '_errs' param will be populated if there was
    # an error with the processing of a login form submission; this is a
    # CGI::Application::Plugin::ValidateRM ->check_rm method thing,
    # called from within the 'cgiapp_prerun' subroutine.  There are
    # tmpl_var fields within the .tmpl loaded below that correspond to
    # the entries named in $err.  After reading it, unset it so that
    # it isn't polluted with information the next time this sub is
    # accessed.
    # ------------------------------------------------------------------
    my $errs = shift || $self->param_read_and_unset('_errs');
    # ------------------------------------------------------------------

    $self->compose_template(
        type => $self->system_template_type,
    );

    my $self_url = $self->query->url;
    $self_url   .= $ENV{'PATH_INFO'} if $ENV{'PATH_INFO'};

    $self->template->param( SELF_URL => $self_url );

    $self->template->param($errs) if $errs;

    return $self->template->output();
}

sub relogin {

    my $self = shift;
    # ------------------------------------------------------------------
    # Note that the '_errs' param will be populated if there was
    # an error with the processing of a login form submission; this is a
    # CGI::Application::Plugin::ValidateRM ->check_rm method thing,
    # called from within the 'cgiapp_prerun' subroutine.  There are
    # tmpl_var fields within the .tmpl loaded below that correspond to
    # the entries named in $err.  After reading it, unset it so that
    # it isn't polluted with information the next time this sub is
    # accessed.
    # ------------------------------------------------------------------
    my $errs = shift || $self->param_read_and_unset('_errs');
    # ------------------------------------------------------------------

    $self->compose_template(
        name => 'template',
        file => 'relogin.html',
        type => $self->system_template_type,
    );

    # ==================================================================
    # Populate the TMPL_VARs in the "relogin.html" form, as given above.
    # (Note that most of these are actually in the relogin_form.html
    # template file.  Look for these in a tmpls/.common(-*) directory.
    # ==================================================================
    my %tmplvars = ();

    $tmplvars{'FORM_NAME'}   = 'relogin';
    $tmplvars{'FORM_METHOD'} = 'POST';
    $tmplvars{'FORM_ACTION'} = $self->query->url();
    $tmplvars{'FORM_ACTION'} .= $ENV{'PATH_INFO'} if $ENV{'PATH_INFO'};

    # ---------------------------------------------------
    # Take whatever form params from the $self that are
    # needed per the specific subclass and put these into
    # the template TMPL_VARs via %tmplvars
    # ---------------------------------------------------
    foreach my $hash ( $self->_relogin_tmpl_params() ) {
        while ( my ($key, $value ) = each %$hash ) {
            $tmplvars{$key} = $value;
        }
    }
    # ---------------------------------------------------

    $self->template->param(\%tmplvars);
    $self->template->param($errs) if $errs;
    # ======== end population of tmpl_vars =============================

    return $self->template->output
        (
         webapp => $self,
         run_mode_tags => {
             COMEFROMRUNMODE => [ COMEFROM => 'relogin' ],
             SUBMITTORUNMODE => [ SUBMITTO => 'relogin' ],
         }
         );
}

sub make_hidden_session_state_tag {

    my $self = shift;

    # ---------------------------------------------------------------------
    # We don't want (well, at least need) to generate a tag in the event of
    # having a cookie contain the state information.  (If we're working
    # through hidden form fields and URL parameters, then we do.)
    # ---------------------------------------------------------------------
    return '' if     !$self->param('session_state');
    return '' if     $self->param('session_state') eq SESSION_IN_COOKIE;
    return '' unless $self->session;
    # ---------------------------------------------------------------------

    return
        '<input type=hidden name="session_id" value="'
        . $self->query->escapeHTML($self->session->{_session_id})
        . '">';
}

# ----------------------------------------------------------
# register_external_callback($phase, \&callback, $order)
#
# This method allows an external class to register a handler during a
# phase of the CGI::Application request. The external class doesn't need
# to have a reference to the CGI::Application $self object.
#
# It's used by Class::DBI subclasses to register callbacks to
# set up their tables during init.
#
# The functionality is not complete - currently only the 'init' phase
# is supported, and only the 'LAST' order is supported.
#
# The interface is designed to be similar to the new CGI::Application
# callbacks interface.
#
# When Framework gets switched over to use the callback-enabled version
# of CGI::Application, the register_external_callback method will probably
# just expose CGI::Application's callback functionality
# ----------------------------------------------------------
my %External_Callbacks;
sub register_external_callback {
    my ($self, $stage, $sub) = @_;

    if ($stage ne 'init') {
        croak "register_external_callback currently only supports the 'init' stage\n";
    }

    $External_Callbacks{'init'} ||= [];

    push @{ $External_Callbacks{'init'} }, $sub;
}

sub cgiapp_init {

    my $self = shift;
    my %params = @_;

    # ----------------------------------------------------------
    # Initialize the config subsystem
    # ----------------------------------------------------------
    $self->config_init;

    my $config = $self->conf($self->config_name)->getall;

    # ----------------------------------------------------------
    # Initialize the logging subsystem
    # ----------------------------------------------------------
    my $logging_initialized_in_parent = $CGI::Application::Framework::Log4Perl_Initialized || 0;

    unless ($logging_initialized_in_parent) {
        my $lc = $self->find_log_config_file;
        Log::Log4perl->init_and_watch($self->find_log_config_file,
                                      $config->{'LoggerConfigsRefreshTime'});
    }

    # ----------------------------------------------------------
    # Set up a logging object and compose it into the $self...
    # and use it everywhere!
    # ----------------------------------------------------------
    my $logger  = Log::Log4perl->get_logger('');

    $logger->debug("logging system initialized: (pid: $$, logger: $logger, init in parent: $logging_initialized_in_parent)");

    $self->compose_object
        (
         name   => 'log',
         object => $logger,
         );
    # ----------------------------------------------------------

    $self->log->debug("In 'cgiapp_init' after log composition, the log is: "
                      . Data::Dumper::Dumper($self->log));

    $self->mode_param('rm');
    $self->param( come_from_rm => 'come_from_' . $self->mode_param);
    $self->param( submit_to_rm => 'submit_to_' . $self->mode_param);
    $self->param( current_rm   => 'current_'   . $self->mode_param);

    $self->start_mode('login');
    $self->run_modes(
                     [ qw (
                           login
                           relogin
                           echo_page
                           invalid_session
                           invalid_checksum
                           )
                       ]
                     );

    my $require_login = '';

    if (exists $config->{'require_login'}) {
        $require_login = $config->{'require_login'};
    } else {
        $require_login = 1;
    }

    $self->param( REQUIRE_LOGIN => $require_login);

    # Call any registered init callbacks at this point

    if ($External_Callbacks{'init'}) {
        foreach my $sub (@{$External_Callbacks{'init'}}) {
            &$sub($self);
        }
    }

    $self->config_template($self->template_params);

}

sub _login_failed_errors   { &__interface_death; }

sub _relogin_failed_errors { &__interface_death; }

sub _login_profile         { &__interface_death; }

sub _relogin_profile       { &__interface_death; }

sub _login_authenticate    { &__interface_death; }

sub _relogin_authenticate  { &__interface_death; }

sub _relogin_test          { &__interface_death; }

sub _initialize_session    { &__interface_death; }

sub _relogin_tmpl_params   { &__interface_death; }

sub _login_tmpl_params     { &__interface_death; }

sub __interface_death {

    my $self = shift;

    # -------------------------------------------------------
    # Recall that noone should ever make this package
    # ("Framework") and file ("Framework.pm") their
    # base class.  Framework.pm is meant to be
    # subclassed, where the subclass has specific
    # information regarding how to do an authentication, how
    # to populate the session with initial data, etc.
    #
    # Framework.pm is meant to provide the login/relogin
    # logic and to create the initial session and logging
    # objects which are composed within the $self.  I have
    # created a series of subroutines, with the name of the
    # sub prefixed with a "_", which indicate the subs that
    # the subclasses need to provide.  If the writer of a
    # subclass forgets to provide one of these then the
    # superclass, Framework, will provide it, but only
    # enough to cause the program to die with a meaningful
    # error message.
    #
    # This subroutine, __interface_death, is the common code
    # for all of the need-to-be-subclassed subroutines that
    # displays an error message which is hopefully meaningful
    # to the module author so that they get to work and do
    # the job they need to.
    # -------------------------------------------------------
    return $self->log->logconfess
        (
         __PACKAGE__
         . " only implements a virtual interface method for ["
         . (caller(1))[3]
         . "] -- implement this yourself in a subclass! "
         );
    # -------------------------------------------------------
}

=item dispatch

This method allows you to choose


=cut
sub dispatch {
    my $class = shift;

    my %params = @_;

    my $projects         = $params{'projects'}
        or croak "CAF->dispatch error: dispatch needs a projects dir\n";

    -d $projects
        or croak "CAF->dispatch error: projects dir does not exist \n";

    my ($project_name, $app_name);
    if ($ENV{'PATH_INFO'} =~ m{^/?(\w*)/(\w*).*$}) {
       $project_name = $1;
       $app_name     = $2;
    }

    # TODO: add option to chdir to appdir

    $project_name
        or croak "CAF->dispatch error: can't find project name from PATH_INFO\n";

    $app_name
        or croak "CAF->dispatch error: can't find app name from PATH_INFO\n";

    my $app_params       = $params{'app_params'} || {};

    my $common_lib_dir      = $params{'common_lib_dir'}
                            || "$projects/$project_name/common-modules";

    my $common_template_dir = $params{'common_template_dir'}
                            || "$projects/$project_name/common-templates";

    my $app_dir             = $params{'app_dir'}
                            || "$projects/$project_name/applications/$app_name/";

    my $app_template_dir    = $params{'app_template_dir'}
                            || "$app_dir/templates";

    my $module              = $params{'module'}
                            || "$app_name.pm";


    $class->_add_to_inc($common_lib_dir);
    $class->_add_to_inc($app_dir);

    my @template_dirs = map { abs_path($_) } (
        $app_template_dir,
        $common_template_dir,
    );

    require $module;

    my $app = $app_name->new(
        TMPL_PATH => \@template_dirs,
        PARAMS    => {
            framework_app_dir => abs_path($app_dir),
            %$app_params
        }
    );

    $app->run;
}

my %Added_To_INC;

sub _add_to_inc {
    my ($self, $path) = @_;

    $path = abs_path($path);

    unless ($Added_To_INC{$path}) {
        unshift @INC, $path;
        $Added_To_INC{$path} = 1;
    }
}


# -------------------------------------------------------
# Configuration Methods
# -------------------------------------------------------

# -------------------------------------------------------
# find_file_in_inc
#
#     my $full_path = find_file_in_inc($filename);
#
# Searches through the paths in @INC to find $filename,
# and returns the first one it finds.
#
# The result is cached, and subsequent calls return the
# cached result.
# -------------------------------------------------------

my %INC_File_Cache;
sub find_file_in_inc {
    my ($self, $filename) = @_;

    return $INC_File_Cache{$filename} if exists $INC_File_Cache{$filename};

    my $found;
    foreach my $inc_path (@INC) {
        my $path = File::Spec->catfile($inc_path, $filename);
        if (-f $path) {
            $found = $path;
            last;
        }
    }

    if ($found) {
        $INC_File_Cache{$filename} = $found;
        return $found;
    }
    return;
}

# -------------------------------------------------------
# find_log_config_file
#
#     my $log_config = find_log_config_file;
#
# Looks up LoggerConfigFile from the default config and then searches
# for it in the paths in @INC
#
# The result is cached, and subsequent calls return the
# cached result.
# -------------------------------------------------------
sub find_log_config_file {
    my ($self) = @_;

    my $config          = $self->conf($self->config_name)->getall;
    my $log_config_file = $config->{'LoggerConfigsFile'};

    -f $log_config_file or croak "log config file $log_config_file not found\n";

    return $log_config_file;

}


# -------------------------------------------------------
# config_file
#
#    my $path_to_config_file = $self->config_file;
#
# Can be overridden in your application.
# Search for an acceptable configuration file
#
# By default, following config files are searched for
# and the first one found is used.
#
#
#     $package/app.conf    #  (where $package is the name of the package
#                          #  of the application, e.g. 'example_1')
#     project.conf
#
#     ../framework.conf
#
# -------------------------------------------------------
sub config_file {
    my ($self) = @_;

    my $app_dir = $self->param('framework_app_dir')
        or croak "CAF->config_file: framework_app_dir not in params; need it to find config file\n";

    my $config_file = abs_path(File::Spec->catdir($app_dir, 'framework.conf'));

    $config_file or croak "CAF->config_file: could not find config file framework.conf in $app_dir\n";

    return $config_file;
}

# -------------------------------------------------------
# db_config_file
#
#    my $path_to_db_config_file = $self->db_config_file;
#
# Can be overridden in your application.
# Search for an acceptable database configuration file
#
# By default, db_config_file returns $self->config_file
# meaning that the same file is used for both database and
# application configuration.
# -------------------------------------------------------

sub db_config_file {
    my ($self) = @_;
    $self->config_file;
}

# -------------------------------------------------------
# config_name
#
#    my $config_name = $self->config_name;
#
# Can be overridden in your application.
# Returns the name of the CGI::Application::Plugin::Config::General
# config to be used by default in the application.
#
# By default, this is left undefined, which means you can use the more
# convenient 'unnamed' form:
#
#    my $config = $self->conf->getall;
#
# -------------------------------------------------------
sub config_name {
    undef;
}


# -------------------------------------------------------
# db_config_name
#
#    my $db_config_name = $self->db_config_name;
#
# Can be overridden in your application.
# Returns the name of the CGI::Application::Plugin::Config::General
# config to be used for database configuration values.  This doesn't
# actually affect how your database classes load their config;
# it's here because the application controls the initialization of
# all configurations, and the database configuration has to be included.
#
# By default, this is left undefined, which means that the database
# config shares the default 'unnamed' config:
#
#    my $db_config = $self->conf->getall;
#
# -------------------------------------------------------
sub db_config_name {
    undef;
}


# -------------------------------------------------------
# config_init
#
#    $self->config_init;
#
# Can be overridden in your application.
# This method initializes the config subsystem,
#
# By default it calls:
#
#     $self->conf($self->config_name)->init($config_file);
#
# and (if the db_config_name is different), it also calls:
#
#     $self->conf($self->db_config_name)->init($db_config_file);
#
# You can initialize multiple configurations here
# if you like.
#
# Be aware that the framework itself expects that
# $self->conf($self->config_name) remains a valid
# configuration.
# -------------------------------------------------------
sub config_init {
    my ($self) = @_;
    my $config_name    = $self->config_name;
    my $db_config_name = $self->db_config_name;

    my $config_file = $self->config_file($self->config_file)
                    || die "Config file not specified\n";

    $self->conf($config_name)->init(
         -ConfigFile => $config_file,
         -Options    => $self->config_general_options,
    );

    # one or both of $config_name and $db_config_name may be undefined
    no warnings 'uninitialized';

    if ($config_name ne $db_config_name) {
        my $db_config_file = $self->config_file($self->config_file);
        if ($db_config_file) {
            $self->conf($db_config_name)->init(
                -ConfigFile => $db_config_file,
            );
        }
        else {
            warn "Config file not specified\n";
        }
    }
}

# -------------------------------------------------------
# config_general_options
#
# Can be overridden in your application.
# This method should return any options to be passed
# on to Config::General.
#
# For instance:
#     sub config_general_options {
#         return {
#             -MergeDuplicateBlocks   => 1,
#             -MergeDuplicateOptions  => 1,
#             -AutoLaunder            => 1,
#             -AutoTrue               => 1,
#         };
#     }
#
# -------------------------------------------------------
sub config_general_options {
    return {
        -IncludeRelative        => 1,
        -MergeDuplicateBlocks   => 1,
        -MergeDuplicateOptions  => 1,
        -AutoLaunder            => 1,
    };
}


sub cgiapp_postrun {

    my $self = shift;

    $self->log->debug(
                      "In 'cgiapp_postrun', the current run mode is : "
                      . $self->get_current_runmode()
                      );

    # ------------------------------------------------------------
    # "touch" the timestamp within the persistent session hash for
    # this session (ultimately derived from / tied together with
    # the 'session_id' cookie.  This is important with regards to
    # the time-out (via _relogin_test) system.
    # ------------------------------------------------------------

    # ------------------------------------------------------------
    # Kill the logger, as it appears as though it gets in the way
    # in a persistent (i.e. mod_perl) environment
    # ------------------------------------------------------------
    $self->remove_composed_object( objectname => 'log')
        if $self->log;
    # ------------------------------------------------------------

    # ------------------------------------------------------------
    # Don't update the timestamp under "special" circumstances;
    # for instance, when the timeout re-login procedure is being
    # run through, or when the program is just being logged in.
    # ------------------------------------------------------------
    return if $self->get_current_runmode() eq $self->start_mode();
    return if $self->get_current_runmode() eq 'invalid_session';
    return if $self->param('_login_loop');
    # ------------------------------------------------------------
    # Not a special circumstance, therefore update the time stamp
    # ------------------------------------------------------------
    $self->session->{_timestamp} = Time::HiRes::time();
    # ------------------------------------------------------------

    return;
}

sub cgiapp_prerun {

    my $self = shift;
    my $config = $self->conf($self->config_name)->getall;

    # =====================================================================
    # I would say that this subroutine forms the core of the Framework
    # framework.  It provides the logic to see if the user is attemping a
    # first-time login, in which case display a login form, authenticate
    # the user's attempts to log in, and upon (eventual) success create
    # a session for the user and allow them to proceed onwards to the
    # application.  It also applies the "relogin" logic, which is
    # essentially a time-out check for the user within the web application.
    # It also enforces various checks on the integrity of the session and
    # the application.  For instance, a checksum on the HMAC with
    # QUERY_STRING parameters.  (I.e. if a user tries to mess with his
    # URL parameters, then they'll be caught and their session killed.)
    # =====================================================================

    $self->log->debug("In 'cgiapp_prerun' just before checking the runmode\n"
                      . " --> current run mode : "
                      . $self->get_current_runmode()
                      . "\n"
                      . " --> start mode : "
                      . $self->start_mode()
                      );

    if ( $self->get_current_runmode() eq $self->start_mode() ) {

        # ---------------------------------------------------------------
        # This is the very very very first loading of the application;
        # the 'rm' query param was not set, so we fell through to the start mode
        # we don't want to do anything in here, so get the hell out.
        # Where we will go to from here is the 'login' run mode, which
        # will display the login screen and that's about it.
        # ---------------------------------------------------------------

        $self->log->debug("Here, ->get_current_runmode eq ->start_mode()\n"
                          . ' --> per get_current_runmode() = '
                          . $self->get_current_runmode()
                          . "\n"
                          . ' --> per start_mode() = '
                          . $self->start_mode());
        return;
    }

    $self->log->debug("I made it past the login run mode check");

    if ( $self->query->param($self->param('come_from_rm'))
        and $self->query->param($self->param('come_from_rm')) eq 'login' ) {

        #
        # This is a "first time" login attempt, so...
        #
        $self->log->debug("About to validate a first time login");

        # ---------------------------------------------------------
        # First, make sure that the form submission is at least
        # barely within specification (i.e. provides a user id and
        # a password, and that the user id is numeric)
        #
        # Note that since we are within cgiapp_prerun, we have to
        # modify our usage of ->check_rm slightly in that we will
        # still use it to check the form and to generate errors
        # but *not* to generate the returning error page.  Rather,
        # we will dispatch that with a prerun_mode handler. (We
        # do generate the "error page", but we ignore it.)
        # ---------------------------------------------------------

        if (!$config->{'use_http_auth'}) {
            my ($errs, $err_page) = $self->check_rm(
                                                    'login',
                                                    $self->_login_profile
                                                    );

            if ( $err_page ) {
                $self->log->debug("I thought err_page was true! ");
                $self->param( _echo => $err_page );
                $self->param( _login_loop => 1 );
                $self->prerun_mode('echo_page');
                return;
            }
            $self->log->debug("First time login form was well-formed");
        }
        # ---------------------------------------------------------

        # ---------------------------------------------------------
        # A numeric user id and a password were provided... now,
        # make sure that they match...
        # ---------------------------------------------------------
        my ($is_login_authenticated, $user) = $self->_login_authenticate();
        if ( $is_login_authenticated ) {

            # ---------------------------------------------------
            # if the authentication is successful then we've got
            # to create an entirely new session, including the
            # cookie that goes along with the session, _and_ we
            # have to register that cookie with the HTTP header
            # outputting aspect of the CGI::Application framework
            # ---------------------------------------------------

            $self->log->debug("Login authenticate:  current runmode = "
                              . $self->get_current_runmode);

            tie(my %session,
                'CGI::Application::Framework::Session',
                undef,
                $config->{'SessionParams'});
            $self->param( session => \%session);
            $self->header_props( -cookie =>
                                 $self->query->cookie
                                 (
                                  -name  => 'session_id',
                                  -value => $session{_session_id},
                                  )
                                 );

            # ---------------------------------------------------

            # ---------------------------------------------------
            # This is the first time we've ever seen the session,
            # so right away define the uid for this session
            # based on the information in the login form.
            # Runmodes that do something will probably care
            # quite a bit regarding which user is trying to do
            # something with the application, natch.
            # ---------------------------------------------------
            $self->_initialize_session($user);
            # ---------------------------------------------------

            # ---------------------------------------------------
            # that's all there is to it... now we'll fall-through
            # to the run-mode to which we should go to upon
            # successful login, as defined by the appropriate
            # hidden input "rm" tag in the login form.
            # ---------------------------------------------------
            $self->param( _login_loop => 0 );
            return;
            # ---------------------------------------------------

        } else {


            # -----------------------------------------------------
            # The user apparently didn't give a good username and
            # password, so we're going to send them back to the login
            # page, which will submit as a new login (i.e. won't
            # ever try to make use of a cookie -- will always
            # create its own if successful)
            # -----------------------------------------------------
            my $errs = $self->_login_failed_errors
                (
                 $is_login_authenticated,
                 $user
                 );

            $self->param( _errs => $errs );
            $self->prerun_mode('login');
            return;
            # -----------------------------------------------------
        }

    } else {

        if ($self->query->param('come_from_rm')) {
            $self->log->debug("Come from run mode = "
                              . $self->query->param('come_from_rm'));
        }
        else {
            $self->log->debug("Come from run mode not specified");
        }

        # --------------------------------------------------------------------
        # Try what we can to get a session ID, and set various parameters
        # corresponding to what we came across in the attempt.  If we can't
        # find a sesison ID, croak.
        # --------------------------------------------------------------------
        my $session_id = '';
        unless ( $session_id = $self->get_session_id ) {

            # ----------------------------------------------------------------
            # XXX fixme --
            # give it a prerun_mode instead so that users don't get a 500
            # error... maybe just piggyback on "invalid_session"?
            # ----------------------------------------------------------------

            $self->log->logconfess(
                 "Session_id couldn't be found:\n"
                 . "   from cookie --> ["
                 . eval { $self->query->cookie('session_id') }. "]\n"
                 . "   from URL    --> ["
                 . eval { $self->query->url_cookie('session_id') }. "]\n"
                 . "   from HFF    --> ["
                 . eval { $self->query->param('_session_id') }. "]\n"
                 . "   state message   --> ["
                 . eval { $self->param('session_state') }
                 . "] "
            );

        }
        # --------------------------------------------------------------------

        # --------------------------------------------------------------------
        # Now, try to reconstitute the session given a session ID.  If we
        # can't find a session with this session ID, kick out to a prerun
        # mode to display an error page to the user.
        # --------------------------------------------------------------------
        my %session = ();

        eval { tie(%session,
                   'CGI::Application::Framework::Session',
                   $session_id,
                   $config->{'SessionParams'}); };

        if ( $@ ) { # there was an error in the creation of the session

            # --------------------------------------------------------------
            # Couldn't create a session, so give the user an error page
            # and log and error.  Hoever, given a $session_id this really
            # shouldn't fail -- it's not like users can create $session_id's
            # directly, and any session_id created by this system should
            # be internally consistent, or else there is a bug somewhere
            # in this code.  (Or maybe some bright boy cooked up a session
            # reaper that act autonomously on this system?)
            # --------------------------------------------------------------

            $self->log->debug
                (
                 "Couldn't make session with session_id [$session_id] "
                 );

            $self->prerun_mode('invalid_session');

            return;
        }
        # --------------------------------------------------------------------

        # --------------------------------------------------------------------
        # We have a %session, so stick it inside of our $self so that we can
        # carry it around the application.
        # --------------------------------------------------------------------
        $self->param( session => \%session );
        # --------------------------------------------------------------------

        # ------------------------------------------------------------------
        # This seems like a good place to put in a check to make sure that
        # any query-string that is provided to us validates against the
        # _checksum field that is also part of the query-string. (If there
        # is no query- string, then the check automatically comes back
        # 'okay'.)
        # ------------------------------------------------------------------
        unless ( $self->checksum_okay ) {

            # -------------------------------------------------
            # If a user tries to modify their URL parameters
            # then their session is destroyed
            # -------------------------------------------------
            tied(%{$self->session})->delete;

            $self->prerun_mode('invalid_checksum');
            return;
        }
        # ------------------------------------------------------------------

        if ( $self->query->param('come_from_rm') and $self->query->param('come_from_rm') eq 'relogin' ) {

            $self->log->debug("come_from_rm eq 'relogin'");

            # --------------------------------------------------------
            # (see below 'else' block for info on how we got here...
            # --------------------------------------------------------

            # ---------------------------------------------------------
            # Make sure that the form submission is at least
            # barely within specification (i.e. provides a user id and
            # a password, and that the user id is numeric)
            #
            # Note that since we are within cgiapp_prerun, we have to
            # modify our usage of ->check_rm slightly in that we will
            # still use it to check the form and to generate errors
            # but *not* to generate the returning error page.  Rather,
            # we will dispatch that with a prerun_mode handler. (We
            # do generate the "error page", but we ignore it.)
            # ---------------------------------------------------------
            my ($errs, $err_page) = $self->check_rm(
                                                    'relogin',
                                                    $self->_relogin_profile
                                                    );

            if ( $err_page ) {
                $self->log->debug("err_page was true");
                $self->param( _echo => $err_page );
                $self->param( _login_loop => 1 );
                $self->prerun_mode('echo_page');
                return;
            }

            my ($is_login_authenticated, $user)
                = $self->_relogin_authenticate();

            if ( $is_login_authenticated ) {

                # ------------------------------------------------------
                # Reauthentication from relogin worked, so continue with
                # the application.  Note that we *don't* need to do all
                # the other set-up crap that we had to do when we
                # successfully authenticated on a first-time login.
                #
                # Note that we "reconstitute" the "original" CGI.pm
                # query object here;  that is, the one that was
                # created from the user's original request/submission
                # before they got trapped in the relogin loop.
                # It would probably be less rude to make the object
                # via classing of ->cgiapp_get_query or ->query than
                # with the direct access to the underlying datum.
                # ------------------------------------------------------

                {
                    no strict 'refs';
                    my $query;

                    $self->{__QUERY_OBJ} = eval $self->session->{_cgi_query};
                }

                delete $self->session->{_cgi_query};

                unless ($self->{__QUERY_OBJ}) {
                    die "could not vivify query object";
                }

                $self->prerun_mode($self->query->param($self->mode_param));

                return;
                # ------------------------------------------------------

            } else {

                # -------------------------------------------------------
                # User didn't successfully re-authenicate, so we have to
                # send them back to the reauthentication page.  Set a few
                # error messages before we do that, though.
                # -------------------------------------------------------
                # XXX fixme -- this should be parcelled off to an area
                # in the subclass that is allowed to know about the
                # specific structure of the login authentication form.
                # -------------------------------------------------------

                my $errs = $self->_relogin_failed_errors
                    (
                     $is_login_authenticated,
                     $user
                     );

                $self->param( _errs => $errs );
                $self->prerun_mode('relogin');

                return;
                # -------------------------------------------------------
            }

        } else {

            $self->log->debug("Looks like we didn't come from 'relogin'");

            if ( $self->_relogin_test() ) {

                # ------------------------------------------------------
                # no problems with time-out check, so continue with
                # web application run...
                # ------------------------------------------------------
                return; # these aren't the droids we're looking for
                # ------------------------------------------------------

            } else {

                # ------------------------------------------------------
                # The session time-out'd, therefore make them cough up a
                # new password, first by redirecting them to a form.
                #
                # Note that the state of the $self-query is saved in
                # the session, so that it may be reconstituted later,
                # for the sake of figuring out where the submit-to
                # run mode was supposed to be, so that form submission
                # data is not lost due to a timeout, etc.
                # ------------------------------------------------------
                my $session_query = '';
                {
                    local $Data::Dumper::Indent = 0;
                    # local $Data::Dumper::Useqq  = 1;  # this creates problems
                    $session_query
                        = Data::Dumper->Dump([$self->query], [ '$query' ]);
                }
                $session_query =~ s/\$query = //;
                $session_query =~ s/;$//;
                $self->session->{_cgi_query} = $session_query;
                $self->prerun_mode('relogin');
                return;
                # ------------------------------------------------------

            } # end of if $self->_relogin_test
        }
    }

    return; # guess that's about it...
}


# ------------------------------------------------------------------
# These methods are new and unique to CGI::Application::Framework
# ------------------------------------------------------------------
sub make_run_mode_tag {

    my $self   = shift;
    my %params = @_;

    my $whichmode = undef;

    if ( $params{whichmode} eq 'COMEFROM' ) {
        $whichmode = 'come_from_' . $self->mode_param();
    } elsif ( $params{whichmode} eq 'CURRENT' ) {
        $whichmode = 'current_' . $self->mode_param();
    } elsif ( $params{whichmode} eq 'SUBMITTO' ) {
        $whichmode = $self->mode_param();
    } else {
        $self->log->logconfess("Unsupported run mode [$params{whichmode}] ");
    }

    return
        '<input type=hidden name="'
        . $whichmode
        . '" value="'
        . $self->query->escapeHTML($params{modevalue})
        . '">';
}

# ------------------------------------------------------------
# Throw in a bunch of methods to support "virtual first-class"
# object composition.
#
# Note that using CGI::Application's built-in "param" method
# is an alternative to this approach, with pros and cons.
# For instance, it it supports the ->session method better.
# ------------------------------------------------------------
sub compose_object {

    my $self = shift;
    my %params = @_;

    # --------------------------------------------------
    # I'm expecting 'name' and 'object' named parameters
    # from @_, which are then shuttled into %params
    # --------------------------------------------------

    # ----------------------------------------------------
    # XXX fixme RLD, Sunday 21 November 2004 -->
    # This subroutine is a good candidate for parameter
    # validation, e.g. through the use of Params::Validate
    # ----------------------------------------------------

    # ----------------------------------------------------
    # Note the triple underscore '___' naming convention.
    # This should avoid collisions with data fields
    # within CGI::Applications.
    # ----------------------------------------------------
    $self->{'___' . uc($params{'name'})} = $params{'object'};
    $self->{'___COMPOSED_OBJECTS'}->{$params{'name'}}
    = ref $params{'object'};

    return $params{'object'};
}

sub remove_composed_object {

    my $self = shift;
    my %params = @_;

    my $objectname = $params{'objectname'};

    my $obj = undef;

    unless ($objectname) {
        $self->log->logcarp
            (
             "Usage \$self->remove_composed_object(objectname => 'some_object'"
             );
    }

    if (exists($self->{'___COMPOSED_OBJECTS'}->{$params{'objectname'}}) ) {

        {
            no strict 'refs';
            $obj = $self->$objectname;
            delete $self->{'___'.uc($objectname)};
        }
        delete $self->{'___COMPOSED_OBJECTS'}->{$params{'objectname'}};

    } else {

        $self->log->logcarp
            (
             "No such composed object with objectname = "
             . $params{objectname}
             );
        return undef;
    }

    return $obj;
}

sub list_all_composed_objects {

    my $self = shift;
    return keys %{$self->{'___COMPOSED_OBJECTS'}};

}

sub param_read_and_set {

    my $self = shift;
    my $param = shift;

    my $value = $self->param($param);
    $self->param($param => ($value || 1));
    return $value;
}

sub param_read_and_unset {

    my $self = shift;
    my $param = shift;

    my $value = $self->param($param);
    $self->param($param => undef);
    return $value;
}

# ----------------------------------------------------------------
# RLD Sunday 21 November 2004 -- 'sub runmode_output' comes out of
# an email conversation today with Rick Delaney regarding
# simplifying the common case of wanting to output the
# ----------------------------------------------------------------
sub runmode_output {

    my $self = shift;

    my $tmplvarsref = undef;
    my %tmplvars    = ();

    if ( ref $_[0] ) {
        $tmplvarsref = $_[0];
    } else {
        %tmplvars = @_;
    }

    $self->compose_template(
        call_level => 2,
    )
        unless $self->{'___TEMPLATE'};
    $self->template->param( $tmplvarsref || \%tmplvars ) if @_;
    return $self->template->output;
}

sub AUTOLOAD {

    my $self = shift;
    my $method = $AUTOLOAD;

    # ---------------------------------------------------------------
    # Note that AUTOLOAD should only work on things that have already
    # been composed.  If not for this then I could end up calling
    # all kinds of crappy nonexistant subroutines that I shouldn't be
    # able to, always get a return value of 'undef', and never get an
    # error of any kind to tell me that I was doing what I probably
    # didn't want to do.  Thus, the 'exists' check in the inner 'if'
    # ---------------------------------------------------------------

    $method =~ s/.*:://;

    return if $method eq 'DESTROY';

    if ( length($method) != 0 ) {
        if ( exists $self->{'___' . uc($method)} ) {
            return $self->{'___' . uc($method)};
        }
    }

    if ($method eq 'log') {
        confess(" [[$AUTOLOAD]] -- No such object "
                               . "referenced by name '$method' to provide ");
    }
    else {
        $self->log->logconfess(" [[$AUTOLOAD]] -- No such object "
                               . "referenced by name '$method' to provide ");
    }

}

sub make_self_url {

    my $self = shift;

    # -----------------------------------------------------------------------
    # I had to do all this ugly stuff to create a URL + query string
    # (the latter if necessary) because a simple $self->query->url(-query=>1)
    # was doing weird stuff, like joining key/value pairs with ';' instead
    # of '&', and building the query string out of the full form submission,
    # rather than just with stuff that's just in the query string) even when
    # the form method was POST. (!?!)
    #
    # Note that this logic isn't advanced enough to handle PATH_INFO,
    # should an application ever use such strange stuff.
    # -----------------------------------------------------------------------
    my $self_url = $self->query->url();
    if ( $ENV{PATH_INFO} ) {
        $self_url .= $ENV{PATH_INFO};
    }
    if ( $ENV{QUERY_STRING} ) {
        $self_url .= '?' . $ENV{QUERY_STRING};
    }
    # -----------------------------------------------------------------------

    return $self_url;
}

sub get_session_id {

    my $self = shift;

    if ( $self->query->cookie('session_id') ) {
        $self->param( session_state => SESSION_IN_COOKIE );
        return $self->query->cookie('session_id');
    }

    if ( $self->query->url_param('_session_id') ) {
        $self->param( session_state => SESSION_IN_URL );
        return $self->query->url_param('_session_id');
    }

    if ( $self->query->param('_session_id') ) {
        $self->param( session_state => SESSION_IN_HIDDEN_FORM_FIELD );
        return $self->query->param('_session_id');
    }

    if ( $self->session and $self->session->{_session_id} ) {
        $self->param( session_state => SESSION_FIRST_TIME );
        return $self->session->{_session_id};
    }

    $self->param( session_state => SESSION_MISSING );
    return undef;
}

sub echo_page {
    my $self = shift;
    return $self->param('_echo');
}

sub make_link {

    # -------------------------------------------------------------------------
    # This sub is a real cock-up, as I wanted to give it backward compatibility
    # with the version of this sub in CGI::Application::Framework::Utils, which
    # is purely procedural.  This version is "smart" enough to know if it should
    # behave procedurally or as a method.  Note that the procedural version
    # of this mandates the Exporter-oriented stuff in this otherwise-OO module.
    #
    # If it is called with a 'url' parameter, it will generate a link with
    # that URL.  Otherwise, if it is called as a method *and* no 'url' has been
    # specified, then it will use the $self->query->url provided by the
    # composed CGI.pm object.
    #
    # By default links will be created with _session_id turned on.  Application
    # programmers can provide their own _session_id by providing it in the
    # qs_args hashref.  If 'no_session' is set to true then _session_id will
    # not be generated automatically (but any provided through qs_args will
    # still be created).
    #
    # 'with_checksum' is set to 1 as default, i.e. MD5 checksums of query
    # strings are created.  The sessioning system should trigger on this to
    # ensure that query-string are as they are supposed to be.
    # ------------------------------------------------------------------------
    #
    # Examples:
    #
    # 1) This will generate a query-string that includes _session_id and
    #    _checksum name/value pairs.  The URL generated will be
    #    $self->query-url.  Nasty characters in the name/value pairs will be
    #    appropriately URL-escaped.
    #
    # $self->template->param( SOME_LINK => $self->make_link
    #                        (
    #                        qs_args => {
    #                            name => 'Richard Dice',
    #                            job  => 'Programmer (& Biz-knob?!?)'
    #                            }
    #                        )
    #                       );
    # 2) No _checksum will be generated.  _session_id will be taken from the
    #    qs_args.  url will be taken as given here as the 'url' param.
    #    Nasty characters in the name/value pairs will be appropriately
    #    URL-escaped.
    #
    # $self->template->param( SOME_LINK => $self->make_link
    #                       (
    #                        with_checksum => 0,
    #                        no_session    => 1,
    #                        url           => 'http://www.nowhere.com/foo.pl'
    #                        qs_args => {
    #                            _session_id => '12345',
    #                            name => 'Richard Dice',
    #                            job  => 'Programmer (& Biz-knob?!?)'
    #                            }
    #                        )
    #                       );
    #
    # 3) Procedural call.  Very important to provide a 'url' parameter in this
    #    situation, though you can leave if off if you think you know what
    #    you're doing.
    #
    # $self->template->param( SOME_LINK => make_link
    #                       (
    #                        url           => $self->query->url,
    #                        qs_args => {
    #                            name => 'Richard Dice',
    #                            job  => 'Programmer (& Biz-knob?!?)'
    #                            }
    #                        )
    #                       );
    # -----------------------------------------------------------------------

    my $self = '';

    # ------------------------------------------------------------------
    # My previous test here of $_[0]->isa(__PACKAGE__) doesn't seem to
    # work in the case where this sub is exported elsewhere.  So,
    # try something a bit more clunky.
    # ------------------------------------------------------------------
    if ( ref($_[0])
         && ! scalar ( grep { ref($_[0]) eq $_ }
                       qw ( SCALAR ARRAY HASH CODE REF GLOB LVALUE ) ) ) {
        $self = shift;
    }
    # ------------------------------------------------------------------

    my $config = $self->conf($self->config_name)->getall;

    my $self_url = $self->query->url;

    if ( $ENV{PATH_INFO} ) {
        $self_url .= $ENV{PATH_INFO};
    }


    my %defaults = (
                    (
                     ref($self)
                     ? (
                        $self->isa(__PACKAGE__)
                        ? (
                           url         => $self_url,
                           _session_id
                           => $self->session->{_session_id},
                           )
                        : ()
                        )
                     : ()
                     ),
                    with_checksum => 1,
                    );
    my %params   = (%defaults, @_);

    unless ( $params{no_session} ) {
        unless ( exists($params{qs_args}->{_session_id}) ) {
            $params{qs_args}->{_session_id} = $params{_session_id};
        }
    }

    my $buffer = '';

    if ( $params{url} ) {
        $buffer .= $params{url}
    }

    if ( $params{qs_args} ) {

        if ( $params{url} ) {
            $buffer .= '?';
        }

        $buffer .= CGI::Enurl::enurl($params{qs_args});
    }

    if ( $params{with_checksum} ) {

        if ( $params{qs_args} ) {
            $buffer .= '&';
        } else {
            if ( $params{url} ) {
                $buffer .= '?';
            }
        }

        $buffer
            .= '_checksum='
            . Digest::MD5::md5_hex(Digest::MD5::md5($buffer . $config->{'md5salt'}));
    }

    return $buffer;

}

sub checksum_okay {

    my $self = shift;
    my $config = $self->conf($self->config_name)->getall;

    # -----------------------------------------------------------------
    # If there are no query string parameters then there is no need to
    # worry about a checksum, therefore everything is okay... return 1
    # -----------------------------------------------------------------
    return 1 unless $ENV{QUERY_STRING};
    # -----------------------------------------------------------------
    # If we have a query string then we *must* have a _checksum
    # parameter... return 0
    # -----------------------------------------------------------------
    return 0 unless $self->query->param('_checksum');
    # -----------------------------------------------------------------

    # -----------------------------------------------------------------
    # Find the checksum and the public info that was used to create
    # the checksum
    # -----------------------------------------------------------------
    my $complete_url = $self->query->url;

    if ( $ENV{PATH_INFO} ) {
        $complete_url .= $ENV{PATH_INFO};
    }

    $complete_url .= '?' . $ENV{QUERY_STRING};
    $complete_url =~ s/_checksum=(\w+)$//;
    my $checksum = $1;
    # -----------------------------------------------------------------

    # -----------------------------------------------------------------
    # Recompute a new checksum with the public info found and the
    # same secret key used to make the original checksum.
    # -----------------------------------------------------------------
    my $recomputed_checksum = Digest::MD5::md5_hex
        (
         Digest::MD5::md5
         ($complete_url . $config->{'md5salt'})
         );
    # -----------------------------------------------------------------

    # -----------------------------------------------------------------
    # If the recomputed checksum is the same as the retrieved checksum
    # then success!
    # -----------------------------------------------------------------
    return 1 if $recomputed_checksum eq $checksum;
    # -----------------------------------------------------------------

    return 0;
}

# -------------------------------------------------------------------
# The "session" subroutine enables the $self->session->{'foobar'}
# syntax, rather than the bulkier $self->param('session')->{'foobar'}
# -------------------------------------------------------------------
sub session {
    my $self = shift;
    return $self->param('session') || undef;
}


sub template_dispatch {
    my ($self, $runmode) = @_;

    if ($self->can($runmode)) {
        return $self->$runmode;
    }
    else {
        $self->log->confess("Can't dispatch to run mode $runmode: run mode not found\n");
    }
}

sub template_params {
    my $self = shift;
    my $config = $self->conf($self->config_name)->getall;
    return $config->{'TemplateParams'};
}

sub system_template_type {
    my $self = shift;
    my $config = $self->conf($self->config_name)->getall;
    return $config->{'TemplateParams'}{'system_template_type'};
}

# -------------------------------------------------------------------
# Configure the Template subsystem
# This is called from init like so:
#
#     $self->config_template($self->template_params);
#
# which usually translates into:
#
#     $self->config_template($config->{'TemplateParams'});
#
# It basically just stores values in $self->{'___TEMPLATE_CONFIG'}
# for later use by the template system.
# -------------------------------------------------------------------
sub config_template {
    my ($self, $params) = @_;

    $params ||= {};

    my $package = ref $self;

    my $include_paths = $self->tmpl_path || [];
    foreach my $key (grep { /^include_path/ } keys %$params) {
        push @$include_paths, $params->{$key};
    }

    my $default_type   = $params->{'default_template_type'};

    my $auto_extension = 1;

    $auto_extension = $params->{'auto_add_template_extension'}
            if exists $params->{'auto_add_template_extension'};

    # assume all keys that have hashref values are type sections
    my %type_config;
    foreach my $type (keys %$params) {
        next unless ref $params->{$type} eq 'HASH';
        $type_config{$type} = $params->{$type};
    }

    $self->{'___TEMPLATE_CONFIG'} = {
        INC            => $include_paths,
        DEFAULT_TYPE   => $default_type,
        AUTO_EXTENSION => $auto_extension,
        TYPE_CONFIG    => \%type_config,
    };

}

# -------------------------------------------------------------------
# template_pre_process is called right before a template is rendered.
# It is called with the $template object as its first parameter.
#
# The job of this callback is to modify any of the parameters to the
# template before it gets filled.
#
# The system needs certain parameters set (such as the run mode tags, the
# SESSION_STATE, etc.).
#
# You can override this method in a subclass, but you must either handle
# these special params yourself, or you should call
#
#     $self->SUPER::template_pre_process($template);
#
# from within your overridden method.
# -------------------------------------------------------------------

sub template_pre_process {
    my ($self, $template) = @_;

    # Change the internal template parameters by reference
    my $params = $template->get_param_hash;

    $params->{'SESSION_STATE'} = $self->make_hidden_session_state_tag;

    if ( $params->{'run_mode_tags'} ) {
    	foreach my $tag ( keys %{$params->{'run_mode_tags'}} ) {
            $params->{$tag} = $self->make_run_mode_tag
             (
              whichmode => $params->{'run_mode_tags'}->{$tag}->[0],
              modevalue => $params->{'run_mode_tags'}->{$tag}->[1],
              );
        }
    }
}

# -------------------------------------------------------------------
# template_pre_process is called right after a template is rendered.
# It is called with the $template object as its first parameter, and
# a reference to the output text as its second parameter.
#
# The job of this callback is to modify the text generated by the template
# engine.
#
# By default the system adds comments to the beginning and ending of every
# template indicating the filename of the template.  This is useful for
# debugging purposes.
#
# You can override this method in a subclass.  If you want to keep the
# included filename comments you can generate them yourself, or you can
# call:
#
#     $self->SUPER::template_post_process($template);
#
# from within your overridden method.
# -------------------------------------------------------------------

sub template_post_process {
    my ($self, $template, $output_ref) = @_;

    if ( $self->{options}->{output_file_name_comment} ) {
        my $fullfilepath = $self->_find_file($template->filename);

        my $output = "<!-- begin template file [[$fullfilepath]] -->"
                   . $$output_ref
                   . "<!-- end template file [[$fullfilepath]] -->";

        $output_ref = \$output;
    }
}

# -------------------------------------------------------------------
# Add a "first class" template subroutine, to handle the common case
# whereby application programmers want a $self->template object.
# If the object already exists then return it.  If not, use the
# compose_template method to create it, and then return the created
# object.  This results from the email conversation between RLD and
# Rick Delaney on Sunday 21 November 2004.
# -------------------------------------------------------------------
sub template {

    my $self = shift;
    return $self->{___TEMPLATE} if $self->{___TEMPLATE};
    return $self->compose_template(
        call_level => 2,
        type       => $self->system_template_type,
    );
}


sub compose_template {
    my $self = shift;

    # ------------------------------------------------------------------
    # Parameter count --
    #    0 --> composed object name == 'template',
    #          file == name of calling subroutine (with package information
    #          removed) plus the appropriate template_extension for this type
    #          (or ".html" if none is specified for this type)
    #
    # + ".html"
    #    1 --> composed object name == 'template',
    #          file == the given argument
    #
    #    more than 1 -->
    #          'name'   => $name,            # template name (defaults to 'template')
    #
    #          'file'   => $file,            # defaults to name of calling sub
    #
    #                                        # if the file has no extension, then
    #                                        # the appropriate template_extension
    #                                        # for this type is added if it is set
    #
    #          'type'   => $type,            # 'HTMLTemplate', 'TemplateToolkit', 'Petal'
    #                                        # or other package in Framework::Template
    #                                        # namespace
    #
    #          'config' => \%conf            # extra configuration values to be passed to
    #                                        # the template driver
    #
    #          'include_paths' => []         # add these extra template include paths
    #
    #          'replace_include_paths' => [] # replace include paths with these paths
    #
    #          'call_level' => 1             # how many levels up the call stack to go to
    #                                        # get the name of the calling sub
    #
    #          'auto_add_template_extension' # turn on or off automatic adding of template
    #                                        # filename extensions for this template composition
    #
    # ------------------------------------------------------------------

    my %params;
    if (@_ == 1) {
        $params{'file'} = $_[0];
    }
    else {
        %params = @_;
    }

    my $type                  = $params{'type'};
    my $name                  = $params{'name'}       || 'template';
    my $call_level            = $params{'call_level'} || 1;
    my $config                = $params{'config'}     || {};
    my $include_paths         = $params{'include_paths'}         || [];
    my $replace_include_paths = $params{'replace_include_paths'} || [];

    my $default_include_paths = $self->{'___TEMPLATE_CONFIG'}{'INC'};

    $type ||= $self->{'___TEMPLATE_CONFIG'}{'DEFAULT_TYPE'} || 'HTMLTemplate';

    my $auto_extension = $self->{'___TEMPLATE_CONFIG'}{'AUTO_EXTENSION'};

    $auto_extension = $params{'auto_add_template_extension'}
            if exists $params{'auto_add_template_extension'};

    my $default_config = $self->{'___TEMPLATE_CONFIG'}{'TYPE_CONFIG'}{$type};

    my $calling_sub = (caller($call_level))[3];

    $calling_sub    = substr(
                             $calling_sub,
                             rindex($calling_sub, '::')+2
                             );


    my $extension = $config->{'template_extension'}
                 || $default_config->{'template_extension'}
                 || '.html';

    my $file = $params{'file'};

    if ($file) {
        # user specified a file, so add extension if requred
        if ($auto_extension) {
            if ($file !~ m{\.[^/]}) { # no extension (i.e. no dot followed by non-slash characters)
                $file .= $extension;
            }
        }
    }
    else {
        # user did not specify a file, so use sub + extension
        $file = $calling_sub . $extension;
    }

    my $tmpl_driver_class = __PACKAGE__ . '::Template::' . $type;

    load $tmpl_driver_class; # Module::Load

    my $tmpl_driver = $tmpl_driver_class->new(
        'webapp' => $self
    );

    $tmpl_driver->filename($file);
    $tmpl_driver->add_config_params($default_config);
    $tmpl_driver->add_config_params($config);

    $tmpl_driver->clear_include_paths;

    if (ref $default_include_paths eq 'ARRAY' and @$default_include_paths) {
        $tmpl_driver->add_include_paths($default_include_paths);
    }
    if (ref $replace_include_paths eq 'ARRAY' and @$replace_include_paths) {
        $tmpl_driver->clear_include_paths;
        $tmpl_driver->add_include_paths($replace_include_paths);
    }

    if (@$include_paths) {
        $tmpl_driver->add_include_paths($include_paths);
    }

    $tmpl_driver->initialize_driver();

    $self->compose_object(
                         name   => $name,
                         object => $tmpl_driver,
                         );


    return $self->$name;
}


sub redirect {

    my $self = shift;
    my $location = shift;

    $self->header_add(-location => $location);
    $self->header_type('redirect');

    return "";
}


sub make_select_option_tmpls {

    &make_select_tmpl;
}

sub make_select_tmpl {

    my $self   = shift;
    my %params = @_;

    my @option_tmpls_rows = ();

    foreach my $option ( @{$params{'options'}->{'options_values'}} ) {

        my %option_tmpls = ();

        $option_tmpls{$params{'options'}->{'options_tmpl'}}
        = $option;

        if ( grep { $option eq $_ }
             @{$params{'selected'}->{'selected_values'}} ) {

            $option_tmpls{$params{'selected'}->{'selected_tmpl'}}
            = 'SELECTED';
        }

        push @option_tmpls_rows, \%option_tmpls;
    }

    return \@option_tmpls_rows;
}

sub make_select_widget {

    my $self   = shift;
    my %params = @_;

    my @options_values  = @{$params{'options'}->{'options_values'}};
    my @options_text    = @{$params{'options'}->{'options_text'}};
    my @selected_values = @{$params{'selected'}->{'selected_values'}};

    my $select_name     = $params{'select_name'};
    my $type            = $params{'type'};
    my $size            = $params{'size'};

    if ( $size eq 'full_list_size' ) {
        $size = scalar(@options_values);
    }

    my $buffer = "<select name=\"$select_name\"";
    if ( lc($type) eq 'multiple' ) {
        $buffer .= " multiple size=\"$size\"";
    }
    $buffer .= ">\n";

    foreach my $i ( 0 .. $#options_values ) {

        my $option_value = $options_values[$i];
        my $option_text  = $options_text[$i];

        $buffer .= "<option value=\"$option_value\"";

        if ( grep { $option_value eq $_ } @selected_values ) {
            $buffer .= " selected";
        }
        $buffer .= ">$option_text</option>\n";
    }
    $buffer .= "</select>";

    return $buffer;
}

sub trim {
    my $self = shift;
    my $item = $_[0]; # copy by value
    $item =~ s/^\s+//;
    $item =~ s/\s+$//;
    return $item;
}


=item parent_template_values

When a run mode is called as an embedded component, it can call the
parent_template_values method to retrieve the template values that were
used to fill the enclosing template.

For instance:

    sub header {
        my $self = shift;
        $self->compose_template;

        my %tmplvars = (
            'title' => 'My glorious home page',
        );

        $self->template->param(%tmplvars, $self->parent_template_values);
        return $self->template->output;
    }

In this example, the values of the enclosing template would override any
values set by the embedded component.

See the documentation in C<CGI::Application::Framework::Template> for
more information.


=cut


sub parent_template_values {
    my $self = shift;

    if (@_) {
        $self->{__PARENT_TMPLVARS} = { @_ };
    }
    $self->{__PARENT_TMPLVARS} ||= {};
    return % {$self->{__PARENT_TMPLVARS} } if wantarray;
    return $self->{__PARENT_TMPLVARS};

}





1;  # bet you thought it'd never come...




