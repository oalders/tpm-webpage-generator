# ////////////////////
# //////////////////// Beginning of CDBI class, based on Class::DBI
# //////////////////// and Class::DBI::mysql. This class has to provide
# //////////////////// enough info for database connections to be made, along
# //////////////////// with whatever other method overrides, utility methods,
# //////////////////// etc. might be needed or desired by the classes that
# //////////////////// are based on CDBI.
# ////////////////////

package CGI::Application::Framework::CDBI;

use warnings;
use strict;

use Module::Load qw( load );

use vars qw ( @ISA );
use Exporter;

use CGI::Application::Framework;

# -------------------------------------------------------------------
# Name of the CAP::CG configuration in which the database info can
# be found
#
# (can be overridden by a subclass)
#
# To use the same configuration file and settings as the main application,
# leave this as the default, which is undefined.
# -------------------------------------------------------------------
sub db_config_name {
    undef;
}

# -------------------------------------------------------------------
# Section within the configuration file in which the database info can
# be found
#
# (should be overridden by a subclass)
#
# For instance, if the database options are in the <database> section,
# return the string 'database'
# -------------------------------------------------------------------
sub db_config_section {
    'database'
}


# -------------------------------------------------------------------
# dbi_connection_info
#
# fetches the database connection information (dsn, username, password)
# from the configuration file and returns them.
#
# Example configuration:
#
#     <db_example>
#         dsn      = DBI:Pg:dbname=example
#         username = test
#         password = seekrit
#     </db_example>
#
# -------------------------------------------------------------------
sub dbi_connection_info {
    my $self = shift;

    my $config = CGI::Application::Plugin::Config::General->get_current_config($self->db_config_name);

    my $db_config = $config->{$self->db_config_section};

    return (
        $db_config->{'dsn'},
        $db_config->{'username'},
        $db_config->{'password'},
    );
}


# -------------------------------------------------------------------
# dbi_options
#
# fetches any database options from the configuration file.
# These are put in the <options> section of the database
# configuration file.  For instance:
#
#     <db_example>
#         username = test
#         password = seekrit
#         dsn      = DBI:Pg:dbname=example
#         <options>
#              AutoCommit = 0
#              RaiseError = 1
#         </options>
#     </db_example>
#
#
# -------------------------------------------------------------------
sub dbi_options {
    my $self = shift;
    my $config = CGI::Application::Plugin::Config::General->get_current_config($self->db_config_name);

    my $db_options = $config->{$self->db_config_section}{'options'} || {};

    my %options = __PACKAGE__->_default_attributes();

    foreach my $opt (keys %$db_options) {
        $options{$opt} = $db_options->{$opt}
    }

    return \%options;
}

# -------------------------------------------------------------------
# set_cdbi_subclass is used to choose (at runtime) which
# database-specific subclass of Class::DBI is to be used
# (e.g. Class::DBI::mysql).
# It determines the subclass from the DBI connect string
# -------------------------------------------------------------------
sub set_cdbi_subclass {
    my $class = shift;

    my $dsn = ($class->dbi_connection_info)[0];

    # Pull the driver from the connect string
    # (regex stolen from CDBI::Loader)
    my ($driver) = $dsn =~ m/^dbi:(\w*?)(?:\((.*?)\))?:/i;

    my $cdbi_subclass = 'Class::DBI::' . $driver;

    load $cdbi_subclass;     # using 'load' from Module::Load

    @ISA = ($cdbi_subclass, 'Exporter');
}


# -------------------------------------------------------------------
# db_Main is Class::DBI's way of setting the database connection.
# All it has to do is return a valid $dbh
#
# It is called *very* often (every time Class::DBI does a
# database query, possibly more often).  So we cache it.
#
# The caching should work in CGI mode and under mod_perl.
# It may need some tweaking in other persistent environments
# -------------------------------------------------------------------
my $Cached_DBH;
sub db_Main {
    my $self = shift;

    my $dbh;

    # Return the cached dbh, if available
    if ( $ENV{'MOD_PERL'} ) {
        # This is for requests only - don't do anything during mod_perl
        # server startup
        unless ( $Apache::ServerStarting ) {
            $dbh = Apache->request->pnotes('dbh');
        }
    }
    else {
        $dbh = $Cached_DBH;
    }

    if ( !$dbh ) {

        $self->set_cdbi_subclass();

        $dbh = DBI->connect(
            $self->dbi_connection_info,
            $self->dbi_options
        );

        # Cache the dbh
        if ( $ENV{'MOD_PERL'} ) {
            # This is for requests only - don't do anything during
            # mod_perl server startup
            unless ( $Apache::ServerStarting ) {
                Apache->request->pnotes( 'dbh', $dbh );
            }
        }
        else {
            $Cached_DBH = $dbh;
        }
    }
    return $dbh;
}


# ------------------------------------------------------------------------
# This idiom copied from the Class::DBI perldoc page on search.cpan.org.
# It is 1/2 of an idiomatic system meant to support transactions. (An
# example of the usage of the second (invocative) half immediately
# follows...
# ------------------------------------------------------------------------
sub do_transaction {

    my $class = shift;
    my ( $code ) = @_;

    # -----------------------------------------------------------
    # Turn off AutoCommit for this scope.
    # A commit will occur at the exit of this block automatically,
    # when the local AutoCommit goes out of scope.
    # -----------------------------------------------------------
    local $class->db_Main->{ AutoCommit };

    # -----------------------------------------------------------
    # Execute the required code inside the transaction.
    # -----------------------------------------------------------
    eval { $code->() };
    # -----------------------------------------------------------
    if ( $@ ) {
	my $commit_error = $@;
	eval { $class->dbi_rollback }; # might also die!
	die $commit_error;
    }
}

# ------------------------------------------------------------------------
# Example of how to set up the idiom for transactions
# ------------------------------------------------------------------------
#
# CDBI::LPI::exam_results::auth_user->do_transaction( sub {
#
#    # Fill this area with code as appropriate to the transaction you
#    # want to do, e.g. ...
#
#    my $artist = Music::Artist->create({ name => 'Pink Floyd' });
#    my $cd = $artist->add_to_cds({
#      title => 'Dark Side Of The Moon',
#      year => 1974,
#    });
#
# });
# ------------------------------------------------------------------------

1; # gotta end a .pm file with a 1, or risk being ostracized...

