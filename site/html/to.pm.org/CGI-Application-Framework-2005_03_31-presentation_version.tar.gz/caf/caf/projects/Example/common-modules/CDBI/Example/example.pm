package CDBI::Example::example;

# ---------------------------------------------------------------------
# In the package name, the last part, "example", refers to the database
# we are working in and the middle part, "Example" the project we are
# working with.  This is just a naming convention, though.
# ---------------------------------------------------------------------

use base qw ( CDBI::Example );

use strict;
use warnings;

# -------------------------------------------------------------------
# Set the section in the database configuration file that contains
# the database connection info.
# By convention, we name it after our database class.
# -------------------------------------------------------------------
sub db_config_section {
    'db_example';
}


# -------------------------------------------------------------------
# We want to set up our tables right at the start of the request
# To do so, we have to instruct Framework to call our setup_tables
# sub during the init phase.
# -------------------------------------------------------------------
CGI::Application::Framework->register_external_callback('init', \&setup_tables);

# -------------------------------------------------------------------
# setup_tables()
# Using the We want to set up our tables right at the start of the request
# To do so, we have to instruct Framework to call our setup_tables
# sub during the init phase.
# -------------------------------------------------------------------
my $Already_Setup_Tables;
sub setup_tables {

    # In a persistent environment, this sub will be called at the
    # beginning of every request.  To avoid repeatedly setting up
    # the tables, we set a flag ($Already_Setup_Tables) after the
    # first time.

    return if $Already_Setup_Tables;

    # Before we can call any Class::DBI methods on our database subclasses
    # (e.g. set_up_table or has_many), we have to decide which db-specific
    # subclass of Class::DBI we are using (e.g. Class::DBI::mysql, Class::DBI::Pg,
    # Class::DBI::SQLite, etc.)  The set_cdbi_subclass takes care of that for us
    __PACKAGE__->set_cdbi_subclass;

    # Create the database classes by setting the package variable ISA
    # (yes, it really is that simple)
    @CDBI::Example::example::users::ISA      = qw ( CDBI::Example::example );
    @CDBI::Example::example::artist::ISA     = qw ( CDBI::Example::example );
    @CDBI::Example::example::song::ISA       = qw ( CDBI::Example::example );
    @CDBI::Example::example::album::ISA      = qw ( CDBI::Example::example );
    @CDBI::Example::example::user_album::ISA = qw ( CDBI::Example::example );
    @CDBI::Example::example::album_song::ISA = qw ( CDBI::Example::example );

    # ----------------------------------------------------------------
    # Set up the tables and their relationships
    #
    # The following tables are simple (i.e. have a single column
    # primary key) so we set them up with the Class::DBI::mysql
    # "set_up_table" method.
    # ----------------------------------------------------------------

    CDBI::Example::example::users->set_up_table("users");
    CDBI::Example::example::users->has_many( albums => 'CDBI::Example::example::user_album');

    CDBI::Example::example::artist->set_up_table("artist");
    CDBI::Example::example::artist->has_many( albums => 'CDBI::Example::example::album' );
    CDBI::Example::example::artist->has_many( songs  => 'CDBI::Example::example::song'  );

    CDBI::Example::example::song->set_up_table("song");

    CDBI::Example::example::album->set_up_table("album");
    CDBI::Example::example::album->has_a( artist_id => 'CDBI::Example::example::artist' );
    CDBI::Example::example::album->has_many(
    		      songs => 'CDBI::Example::example::album_song',
    		      { order_by => 'track_num' }
    		      );

    # ---------------------------------------------------------------------------
    # The below are slighly more complex (though still generaly simple) tables
    # that require that we explicitly declare the colums within them. (I.e. they
    # have primary keys that are made up of multiple columns.)
    # ---------------------------------------------------------------------------

    CDBI::Example::example::user_album->set_up_table('user_album');
    CDBI::Example::example::user_album->has_many(
    		      albums => 'CDBI::Example::example::album',
    		      );

    CDBI::Example::example::album_song->set_up_table('album_song');
    CDBI::Example::example::album_song->has_a( song_id => 'CDBI::Example::example::song' );

    $Already_Setup_Tables = 1;
}


1;


1;

