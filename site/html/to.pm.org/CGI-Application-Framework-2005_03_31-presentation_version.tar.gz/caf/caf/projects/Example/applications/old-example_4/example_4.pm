package example_4;

use strict;    # always a good idea to include these in your
use warnings;  # modules

use lib ('common-modules'); # should reflect your own installation

# ------------------------------------------------------------------
# You must have this!  Or rather, you must "use base" a module that
# inherets from CGI::Application::Framework and adhers to its
# specifications.
# ------------------------------------------------------------------
use base qw ( Example );
# ------------------------------------------------------------------

use Time::Format qw ( %time );

sub setup {

    my $self = shift;

    $self->run_modes( [ qw ( main_view ) ] );

    # -------------------------------------------------------------
    # Note that the registry could be populated via the
    # "included_template_registry" anywhere before the calling of
    # "compose_template" (e.g. here in the startup, in the run
    # mode before compose_template is called, or even in the
    # CGI::Application::Framework::Project file somewhere maybe)
    # and the key/value template name / subroutine reference
    # specification that is needed for the initialization call
    # to this subroutine could (and probably should) be parcelled
    # off into some other file & namespace somewhere, as these
    # are likely to be common to many applications across a
    # project
    # -------------------------------------------------------------
}

sub main_view {

    my $self = shift;

    # ------------------------------------------------------------------
    # Create HTML::Template object and compose within the $self
    # ------------------------------------------------------------------
    $self->compose_template();
    # ------------------------------------------------------------------

    ### ================================================================
    ### Now, populate the template variables (a.k.a. TMPL_VARs) within
    ### the composed HTML::Template object
    ### ================================================================

    my %tmplvars = (); # we'll use this to accumulate tmpl_var values

    # ----------------------------------------------------------------
    # Here's a selection of various things that you can do to populate
    # simple TMPL_VARs.
    # ----------------------------------------------------------------
    $tmplvars{'load_count'}     = ++$self->session->{count};
    $tmplvars{'SELF_HREF_LINK'} = $self->make_link
	(
	 qs_args => {
	     rm => 'main_view',
	 }
	 );
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # We're done -- use %tmplvars to populate the composed
    # HTML::Template object within the $self
    # ------------------------------------------------------------------
    $self->template->param(\%tmplvars);
    # ------------------------------------------------------------------

    ### ================================================================
    ### /end of populating HTML::Template TMPL_VARs
    ### ================================================================

    ### ================================================================
    ### All done -- output rendered template with interpolated TMPL_VARs
    ### ================================================================
    return $self->template->output();
    ### ================================================================
}

sub outer_component {
    my $self = shift;

    $self->compose_template();

    my %tmplvars = ();

    $tmplvars{'time_within_include'} = $time{'yyyy/mm/dd hh:mm:ss'};

    $self->template->param(\%tmplvars);

    return $self->template->output();

}

sub inner_component {
    my $self = shift;

    $self->compose_template();

    my %tmplvars = ();
    $tmplvars{'inner_var'} = 'some inner value';

    $self->template->param(\%tmplvars);

    return $self->template->output();
}

1;  # most Perl .pm files end in "1;".  It's tradition.


