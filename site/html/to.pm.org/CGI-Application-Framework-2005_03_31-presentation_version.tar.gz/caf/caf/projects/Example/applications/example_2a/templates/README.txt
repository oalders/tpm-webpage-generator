Example 5 -- this is mean to show how to use the $self->make_link
method to bounce between applications that use the same sessioning
scheme.  When this is done, the session is maintained between the
various applications.  Note that you must forward to a specific
runmode in the receiving application by name.
