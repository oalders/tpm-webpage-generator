Example 1 -- this is meant to show the basic usage of
CGI::Application::Framework.  See the inline documentation within
example_1.pm for details.