Example 2 -- a "CRUD" application using Class::DBI (CRUD -- create,
read, update, delete... the standard database manipulations.)
