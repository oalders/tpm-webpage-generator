Example 3 -- to show the use of has_many relationships with Class::DBI
and how to populate multiply-embedded TMPL_LOOP statements with those
has_many relationships.
