
# This script is loaded via a PerlRequire in Apache's httpd.conf It loads
# the logging configuration and the log4perl system so that the logger
# object is inherited by each Apache child

use strict;
use File::Spec;
use Log::Log4perl;

# The following magic is used to include in Perl's library search path the
# directory containing this script

my $script_dir;
BEGIN {
    my ($volume, $directories, $file) = File::Spec->splitpath(__FILE__);
    $script_dir = File::Spec->catpath($volume, $directories, '');
}

# Pull in the same configuration as Framework.pm does.
# Assumptions:
#     local.conf exists somewhere in @INC
#     local.conf contains settings LoggerConfigsFile
#     local.conf contains settings LoggerConfigsRefreshTime
#     the file specified by LoggerConfigsFile exists in @INC
#
# if your configuration differs from the above, then modify the settings
# below accordingly

use CGI::Application::Framework;

# Find local.conf in path
my $config_file = "$script_dir/framework.conf";

use Config::General;

my $conf = Config::General->new(
    -ConfigFile => $config_file,
);


my %config = $conf->getall;

my $logger_configs_file         = $config{'LoggerConfigsFile'};
my $logger_configs_refresh_time = $config{'LoggerConfigsRefreshTime'};

# Set a global Perl variable to indicate that we have initialized the
# logging system.  Is there a better way of doing this?  Or a better
# variable name?

$CGI::Application::Framework::Log4Perl_Initialized = 1;

unless ( Log::Log4perl->initialized() ) {
    Log::Log4perl->init_and_watch(
        $logger_configs_file,
        $logger_configs_refresh_time,
        $config{'LoggerConfigsRefreshTime'},
    );
}

1;


