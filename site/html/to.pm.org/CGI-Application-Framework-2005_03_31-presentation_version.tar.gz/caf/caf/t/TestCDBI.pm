
package TestCDBI;

use base qw ( CGI::Application::Framework::CDBI );

use strict;
use warnings;

sub db_config_section {
    'db_test';
}

CGI::Application::Framework->register_external_callback('init', \&setup_tables);

sub setup_tables {

    __PACKAGE__->set_cdbi_subclass;

    __PACKAGE__->create_database;

    @TestCDBI::users::ISA = qw ( TestCDBI );
    TestCDBI::users->set_up_table("users");

}

sub create_database {
    my $class = shift;

    my $config = CGI::Application::Plugin::Config::General->get_current_config($class->db_config_name);
    my $dsn = $config->{$class->db_config_section}{'dsn'};

    if ($dsn =~ /^dbi:sqlite:dbname=(.*)$/i) {
        my $db_file = $1;
        if (-f $db_file) {
            unlink $db_file;
        }
    }
    else {
        die "could not determine database filename from dsn: $dsn\n";
    }

    # Don't care if this fails
    eval { $class->db_Main->do( "DROP TABLE users" ); };

    $class->db_Main->do(
        qq{
            CREATE TABLE users (
              uid INTEGER NOT NULL PRIMARY KEY,
              username varchar(50) UNIQUE,
              fullname varchar(50),
              password varchar(50)
            );
        }
    );
    $class->db_Main->do(
        qq{
            INSERT INTO users (username, fullname, password) VALUES('test', '', 'seekrit');
        }
    );
    $class->db_Main->do(
        qq{
            INSERT INTO users (username, fullname, password) VALUES('test\@example.com', '', 'sooperseekrit');
        }
    );
    $class->db_Main->do(
        qq{
            INSERT INTO users (username, fullname, password) VALUES('bubba', 'Bubba the Beatific', 'banana');
        }
    );
}


1;


