The INSTALL.txt document tells you how to install
CGI::Application::Framework (CAF).

GETTING_STARTED.txt describes how to program using the Framwork.
